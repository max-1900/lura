#!/bin/bash

./tdcli -s ./bot.lua -p apimode --bot=759584661:AAHbzZeHgfOPDxVVG2WNBwj1noP2K64NQ3M