do local data = {
  BotUsername = "@",
  sudo_users = {282958812,568049869},
  token = "404254048:AAFQv0VKs5sto_0HBvXpXDffPU1koW0PCfU",
  channel_id ="@botcollege"
}
return data
end