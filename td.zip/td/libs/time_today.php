<?php
include('./php/jdf.php');
echo jdate('H:i:s Y F j ,l', time()) . PHP_EOL ;


