#!/bin/bash
COUNTER=1
while(true) do
./launch.sh l
let COUNTER=COUNTER+1 
done